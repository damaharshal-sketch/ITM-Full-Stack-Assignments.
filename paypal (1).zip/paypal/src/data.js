export const menus = {
  Personal: ["Send Money", "Shop Online", "Pay in Store", "PayPal Credit", "Mobile App"],
  Business: ["Accept Payments", "Invoicing", "Checkout", "Business Loans", "Payouts"],
  Partners: ["Become a Partner", "Developer Portal", "Marketplaces", "Platforms"],
  "Useful Info": ["Help Center", "Fees", "Security", "Contact Us", "Community"],
};

export const tabs = ["Personal", "Business"];

export const heroContent = {
  Personal: {
    title: "PayPal",
    tagline: "Send, shop and save with confidence",
    description:
      "Pay friends, shop online and manage your money in one secure place, anywhere you go.",
    primaryCta: "Sign Up",
    secondaryCta: "Learn More",
  },
  Business: {
    title: "PayPal Open",
    tagline: "One platform for your business needs",
    description:
      "PayPal Open unifies your PayPal business solutions to help you get paid, get growing, and get ahead.",
    primaryCta: "Sign Up",
    secondaryCta: "Contact Sales",
  },
};

export const forms = {
  login: {
    title: "Log in to PayPal",
    submit: "Log In",
    success: "You are logged in. Welcome back!",
    fields: [
      { name: "email", label: "Email", type: "email" },
      { name: "password", label: "Password", type: "password" },
    ],
  },
  signup: {
    title: "Create your account",
    submit: "Sign Up",
    success: "Your account has been created.",
    fields: [
      { name: "name", label: "Full name", type: "text" },
      { name: "email", label: "Email", type: "email" },
      { name: "password", label: "Password", type: "password" },
    ],
  },
  contact: {
    title: "Contact Sales",
    submit: "Send Message",
    success: "Thanks for reaching out. Our sales team will contact you soon.",
    fields: [
      { name: "name", label: "Full name", type: "text" },
      { name: "email", label: "Work email", type: "email" },
      { name: "message", label: "How can we help?", type: "textarea" },
    ],
  },
  learn: {
    title: "Learn more about PayPal",
    submit: "Close",
    success: "",
    fields: [],
  },
};
