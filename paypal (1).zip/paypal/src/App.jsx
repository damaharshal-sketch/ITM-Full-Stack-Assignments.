import { useEffect, useRef, useState } from "react";
import { menus, tabs, heroContent, forms } from "./data.js";

function Logo() {
  return (
    <svg className="logo" viewBox="0 0 24 28" aria-label="PayPal">
      <path fill="#003087" d="M7.1 27.2l.5-3.2H3.9L6.5 7.4A.8.8 0 0 1 7.300 6.700h6.400c2.100 0 3.600.5 4.400 1.500.4.500.6 1 .7 1.600.1.600.1 1.300 0 2.100v.6l.5.300c.4.200.8.500 1.100.9.500.5.800 1.200.9 1.900.1.800.1 1.800-.2 2.900-.3 1.300-.8 2.300-1.400 3.100-.6.800-1.400 1.400-2.300 1.800-.9.400-1.900.6-3.100.6h-.7c-.5 0-1 .2-1.400.5-.4.300-.6.800-.7 1.300l-.1.300-.8 5.100z" />
      <path fill="#009cde" d="M20.600 10.600c0 .1 0 .3-.1.400-1 5.200-4.400 7-8.800 7H9.500c-.5 0-1 .4-1.100.9l-1.100 7.100-.3 2c0 .4.300.7.600.7h4c.5 0 .9-.3 1-.8v-.2l.8-4.800.1-.3c.1-.5.500-.8 1-.8h.6c4 0 7-1.600 7.900-6.200.4-1.900.2-3.500-.8-4.600-.3-.3-.7-.6-1.200-.8z" />
      <path fill="#012169" d="M19.500 10.200c-.1 0-.3-.1-.4-.1l-.5-.1c-.6-.1-1.300-.1-2-.1h-5.300c-.1 0-.3 0-.4.100-.2.100-.4.400-.4.600l-1.100 7.300v.2c.1-.5.600-.9 1.100-.9h2.300c4.400 0 7.800-1.800 8.800-7 0-.1 0-.3.100-.4-.3-.2-.5-.3-.8-.4l-.4-.1z" />
    </svg>
  );
}

function Chevron({ open }) {
  return (
    <svg className={open ? "chevron open" : "chevron"} viewBox="0 0 10 6" aria-hidden="true">
      <path d="M1 1l4 4 4-4" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function Header({ onOpen, onNavigate }) {
  const [openMenu, setOpenMenu] = useState(null);
  const navRef = useRef(null);

  useEffect(() => {
    const handleClick = (event) => {
      if (navRef.current && !navRef.current.contains(event.target)) {
        setOpenMenu(null);
      }
    };
    const handleKey = (event) => {
      if (event.key === "Escape") setOpenMenu(null);
    };
    document.addEventListener("mousedown", handleClick);
    document.addEventListener("keydown", handleKey);
    return () => {
      document.removeEventListener("mousedown", handleClick);
      document.removeEventListener("keydown", handleKey);
    };
  }, []);

  const toggleMenu = (name) => setOpenMenu(openMenu === name ? null : name);

  const chooseItem = (name, item) => {
    setOpenMenu(null);
    onNavigate(name, item);
  };

  return (
    <header className="header">
      <div className="header-inner">
        <nav className="nav" aria-label="Main" ref={navRef}>
          <a href="#top" className="logo-link">
            <Logo />
          </a>
          <ul className="nav-list">
            {Object.keys(menus).map((name) => (
              <li key={name} className="nav-entry">
                <button
                  type="button"
                  className={openMenu === name ? "nav-item active" : "nav-item"}
                  aria-expanded={openMenu === name}
                  onClick={() => toggleMenu(name)}
                >
                  {name}
                  <Chevron open={openMenu === name} />
                </button>
                {openMenu === name && (
                  <ul className="dropdown">
                    {menus[name].map((item) => (
                      <li key={item}>
                        <button type="button" className="dropdown-item" onClick={() => chooseItem(name, item)}>
                          {item}
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            ))}
          </ul>
        </nav>
        <div className="auth">
          <button type="button" className="btn btn-outline" onClick={() => onOpen("login")}>Log In</button>
          <button type="button" className="btn btn-primary" onClick={() => onOpen("signup")}>Sign Up</button>
        </div>
      </div>
    </header>
  );
}

function Toggle({ active, onChange }) {
  return (
    <div className="toggle" role="tablist">
      {tabs.map((tab) => (
        <button
          key={tab}
          type="button"
          role="tab"
          aria-selected={active === tab}
          className={active === tab ? "toggle-btn active" : "toggle-btn"}
          onClick={() => onChange(tab)}
        >
          {tab}
        </button>
      ))}
    </div>
  );
}

function Hero({ tab, onTabChange, onOpen }) {
  const content = heroContent[tab];
  const secondary = tab === "Business" ? "contact" : "learn";
  return (
    <section className="hero" id="top">
      <Toggle active={tab} onChange={onTabChange} />
      <h1 className="hero-title">{content.title}</h1>
      <p className="hero-tagline">{content.tagline}</p>
      <p className="hero-text">{content.description}</p>
      <div className="hero-actions">
        <button type="button" className="btn btn-yellow btn-lg" onClick={() => onOpen("signup")}>
          {content.primaryCta}
        </button>
        <button type="button" className="btn btn-ghost btn-lg" onClick={() => onOpen(secondary)}>
          {content.secondaryCta}
        </button>
      </div>
    </section>
  );
}

function Modal({ title, onClose, children }) {
  useEffect(() => {
    const handleKey = (event) => {
      if (event.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, [onClose]);

  return (
    <div className="overlay" onMouseDown={onClose}>
      <div
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onMouseDown={(event) => event.stopPropagation()}
      >
        <button type="button" className="modal-close" aria-label="Close" onClick={onClose}>
          ×
        </button>
        <h2 className="modal-title">{title}</h2>
        {children}
      </div>
    </div>
  );
}

function ModalForm({ config, onClose }) {
  const [submitted, setSubmitted] = useState(false);

  if (config.fields.length === 0) {
    return (
      <>
        <p className="modal-text">
          Send money, shop online and manage your balance with buyer and seller protection built in.
        </p>
        <button type="button" className="btn btn-primary btn-block" onClick={onClose}>
          {config.submit}
        </button>
      </>
    );
  }

  if (submitted) {
    return (
      <>
        <p className="modal-success">{config.success}</p>
        <button type="button" className="btn btn-primary btn-block" onClick={onClose}>
          Done
        </button>
      </>
    );
  }

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <form onSubmit={handleSubmit} className="form">
      {config.fields.map((field) => (
        <label key={field.name} className="field">
          <span>{field.label}</span>
          {field.type === "textarea" ? (
            <textarea name={field.name} rows="4" required />
          ) : (
            <input name={field.name} type={field.type} required />
          )}
        </label>
      ))}
      <button type="submit" className="btn btn-primary btn-block">
        {config.submit}
      </button>
    </form>
  );
}

export default function App() {
  const [tab, setTab] = useState("Business");
  const [modal, setModal] = useState(null);
  const [notice, setNotice] = useState("");

  const handleNavigate = (menu, item) => {
    if (menu === "Personal") setTab("Personal");
    if (menu === "Business") setTab("Business");
    if (item === "Contact Us") {
      setModal("contact");
      return;
    }
    setNotice(`${item} page is not available in this demo.`);
  };

  useEffect(() => {
    if (!notice) return undefined;
    const timer = setTimeout(() => setNotice(""), 2500);
    return () => clearTimeout(timer);
  }, [notice]);

  const closeModal = () => setModal(null);

  return (
    <>
      <Header onOpen={setModal} onNavigate={handleNavigate} />
      <main>
        <Hero tab={tab} onTabChange={setTab} onOpen={setModal} />
      </main>
      {notice && <div className="toast" role="status">{notice}</div>}
      {modal && (
        <Modal title={forms[modal].title} onClose={closeModal}>
          <ModalForm key={modal} config={forms[modal]} onClose={closeModal} />
        </Modal>
      )}
    </>
  );
}
