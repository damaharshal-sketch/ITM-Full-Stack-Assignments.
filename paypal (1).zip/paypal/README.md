# PayPal Open

Single page React app with static data.

    npm install
    npm run dev
